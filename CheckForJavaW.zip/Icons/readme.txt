﻿------------------------------------------------
Red Orb Alphabet Icons (by IconArchive.com)
------------------------------------------------

This work is licensed under a
Creative Commons Attribution 3.0 License.
http://creativecommons.org/licenses/by/3.0/

This means you may use it for any purpose,
and make any changes you like.
All I ask is that you include a link back
to http://www.iconarchive.com in your credits.

Special thanks to:
- Devotopia.com
- Fontdiner.com (for the beautiful font called "Huggable")


Copyright © 2010 IconArchive.com
